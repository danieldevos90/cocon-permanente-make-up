<?php
/**
 * COCONPM Custom Functions
 * =========================
 * Add ALL of this code to the END of your theme's functions.php
 * 
 * IMPORTANT: After adding this, REMOVE the old inline CSS functions:
 * - coconpm_card_alignment_fix
 * - coconpm_pdp_styles  
 * - coconpm_cart_checkout_styles
 * These were temporary and make the site slow!
 */

/**
 * Enqueue COCONPM Custom Stylesheets
 * Loads CSS files properly (cacheable, fast)
 */
function coconpm_enqueue_custom_styles() {
    $css_path = get_stylesheet_directory_uri() . '/css/';
    $css_dir = get_stylesheet_directory() . '/css/';
    $version = '2.0.1';
    
    // Always load buttons
    if (file_exists($css_dir . 'coconpm-buttons.css')) {
        wp_enqueue_style('coconpm-buttons', $css_path . 'coconpm-buttons.css', array(), $version);
    }
    
    // Shop page
    if (function_exists('is_shop') && (is_shop() || is_product_category() || is_product_tag())) {
        if (file_exists($css_dir . 'coconpm-shop.css')) {
            wp_enqueue_style('coconpm-shop', $css_path . 'coconpm-shop.css', array(), $version);
        }
    }
    
    // Single product page
    if (function_exists('is_product') && is_product()) {
        if (file_exists($css_dir . 'coconpm-product.css')) {
            wp_enqueue_style('coconpm-product', $css_path . 'coconpm-product.css', array(), $version);
        }
    }
    
    // Cart page
    if (function_exists('is_cart') && is_cart()) {
        if (file_exists($css_dir . 'coconpm-cart.css')) {
            wp_enqueue_style('coconpm-cart', $css_path . 'coconpm-cart.css', array(), $version);
        }
    }
    
    // Checkout page
    if (function_exists('is_checkout') && is_checkout()) {
        if (file_exists($css_dir . 'coconpm-checkout.css')) {
            wp_enqueue_style('coconpm-checkout', $css_path . 'coconpm-checkout.css', array(), $version);
        }
    }
    
    // Blog pages
    if (is_home() || is_category() || is_tag() || is_author() || is_date() || (is_single() && get_post_type() === 'post')) {
        if (file_exists($css_dir . 'coconpm-blog.css')) {
            wp_enqueue_style('coconpm-blog', $css_path . 'coconpm-blog.css', array(), $version);
        }
    }
    
    // Featured products (load on front page and pages with shortcodes)
    if (is_front_page() || is_page()) {
        if (file_exists($css_dir . 'coconpm-featured.css')) {
            wp_enqueue_style('coconpm-featured', $css_path . 'coconpm-featured.css', array(), $version);
        }
    }
}
add_action('wp_enqueue_scripts', 'coconpm_enqueue_custom_styles', 20);

/**
 * Include custom WooCommerce functions
 */
if (file_exists(get_stylesheet_directory() . '/inc/woocommerce-custom.php')) {
    require_once get_stylesheet_directory() . '/inc/woocommerce-custom.php';
}

/**
 * Hide sidebar on WooCommerce pages
 */
function coconpm_remove_sidebar_woocommerce() {
    if (function_exists('is_woocommerce') && (is_woocommerce() || is_cart() || is_checkout())) {
        remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);
    }
}
add_action('wp', 'coconpm_remove_sidebar_woocommerce');

/**
 * Force full-width layout on WooCommerce pages
 */
function coconpm_woocommerce_body_class($classes) {
    if (function_exists('is_woocommerce') && (is_woocommerce() || is_cart() || is_checkout())) {
        $classes[] = 'et_full_width_page';
        // Remove right sidebar class
        $key = array_search('et_right_sidebar', $classes);
        if ($key !== false) {
            unset($classes[$key]);
        }
    }
    return $classes;
}
add_filter('body_class', 'coconpm_woocommerce_body_class');
