<?php
/**
 * COCONPM Custom Styles Loader
 * Add this code to your theme's functions.php or a custom plugin
 */

function coconpm_enqueue_custom_styles() {
    $css_path = get_stylesheet_directory_uri() . '/css/';
    $css_dir = get_stylesheet_directory() . '/css/';
    $version = '2.0.0';
    
    // Always load buttons
    if (file_exists($css_dir . 'coconpm-buttons.css')) {
        wp_enqueue_style('coconpm-buttons', $css_path . 'coconpm-buttons.css', array(), $version);
    }
    
    // Shop page
    if (is_shop() || is_product_category() || is_product_tag()) {
        if (file_exists($css_dir . 'coconpm-shop.css')) {
            wp_enqueue_style('coconpm-shop', $css_path . 'coconpm-shop.css', array(), $version);
        }
    }
    
    // Single product page
    if (is_product()) {
        if (file_exists($css_dir . 'coconpm-product.css')) {
            wp_enqueue_style('coconpm-product', $css_path . 'coconpm-product.css', array(), $version);
        }
    }
    
    // Cart page
    if (is_cart()) {
        if (file_exists($css_dir . 'coconpm-cart.css')) {
            wp_enqueue_style('coconpm-cart', $css_path . 'coconpm-cart.css', array(), $version);
        }
    }
    
    // Checkout page
    if (is_checkout()) {
        if (file_exists($css_dir . 'coconpm-checkout.css')) {
            wp_enqueue_style('coconpm-checkout', $css_path . 'coconpm-checkout.css', array(), $version);
        }
    }
    
    // Blog pages
    if (is_home() || is_category() || is_tag() || is_author() || is_date() || is_single()) {
        if (file_exists($css_dir . 'coconpm-blog.css')) {
            wp_enqueue_style('coconpm-blog', $css_path . 'coconpm-blog.css', array(), $version);
        }
    }
    
    // Featured products (load on front page or if shortcode is used)
    if (is_front_page() || is_page()) {
        if (file_exists($css_dir . 'coconpm-featured.css')) {
            wp_enqueue_style('coconpm-featured', $css_path . 'coconpm-featured.css', array(), $version);
        }
    }
}
add_action('wp_enqueue_scripts', 'coconpm_enqueue_custom_styles', 9999);
