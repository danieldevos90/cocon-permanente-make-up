COCONPM Custom Templates Upload Guide
======================================

FOLDER STRUCTURE:
Upload files to wp-content/themes/Divi/ maintaining this structure:

/wp-content/themes/Divi/
├── css/
│   ├── coconpm-blog.css
│   ├── coconpm-buttons.css
│   ├── coconpm-cart.css
│   ├── coconpm-checkout.css
│   ├── coconpm-featured.css
│   ├── coconpm-product.css
│   └── coconpm-shop.css
├── inc/
│   └── woocommerce-custom.php
├── woocommerce/
│   ├── content-product.php         (Product cards on shop page)
│   ├── single-product.php          (Single product page wrapper)
│   ├── cart/
│   │   └── cart.php                (Cart page)
│   ├── checkout/
│   │   └── form-checkout.php       (Checkout page)
│   └── single-product/
│       ├── product-image.php       (Product gallery)
│       ├── related.php             (Related products)
│       └── add-to-cart/
│           ├── simple.php          (Simple product add to cart)
│           └── variable.php        (Variable product add to cart)
├── archive.php                     (Blog archive)
├── single.php                      (Single blog post)
└── archive-product.php             (Shop page)

STEP 1: Upload all files via FTP
- Host: coconpermanentemakeup.nl
- Username: coconper
- Path: /domains/coconpermanentemakeup.nl/public_html/wp-content/themes/Divi/

STEP 2: Add CSS loader to functions.php
Copy the code from coconpm-enqueue-styles.php and add it to the END of:
/wp-content/themes/Divi/functions.php

STEP 3: Make sure inc/woocommerce-custom.php is included
Add this line to functions.php if not already present:
require_once get_stylesheet_directory() . '/inc/woocommerce-custom.php';

STEP 4: Clear cache
Go to WordPress admin → LiteSpeed Cache → Toolbox → Purge All

