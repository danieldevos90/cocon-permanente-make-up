<?php
/**
 * Internationalization.
 *
 * @package Divi
 */

return [
	'Add Background Color' => esc_html__( 'Add Background Color', 'et_builder' ),
];
