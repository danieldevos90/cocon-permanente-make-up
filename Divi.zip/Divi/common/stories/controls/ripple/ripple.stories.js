// Internal dependencies.
import Ripple from '../../../controls/ripple/ripple';


export default {
  title: 'Controls/Ripple',
  component: Ripple,
};

export const Default = {
};
