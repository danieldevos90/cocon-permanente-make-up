<?php
/**
 * Single Product Template - Simple Bootstrap Layout
 *
 * @package Divi
 * @subpackage WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<style>
/* Force Quantity Input to Match Button - Inline Override */
.quantity input[type="number"],
.woocommerce .quantity .qty,
input.qty,
.input-text.qty {
	font-size: 16px !important;
	font-weight: 500 !important;
	color: #C64193 !important;
	border: 2px solid #C64193 !important;
	padding: 12px 32px !important;
	height: 48px !important;
	line-height: 1.5 !important;
	background: transparent !important;
	font-family: inherit !important;
	letter-spacing: normal !important;
	text-transform: none !important;
}
</style>

<div id="main-content">
	<div class="container py-5">
		
		<?php while ( have_posts() ) : the_post(); ?>
			<?php 
				global $product;
				if ( ! is_a( $product, 'WC_Product' ) ) {
					$product = wc_get_product( get_the_ID() );
				}
			?>
			
			<!-- Breadcrumb -->
			<nav aria-label="breadcrumb" class="mb-4">
				<?php woocommerce_breadcrumb(); ?>
			</nav>
			
			<!-- Product Detail -->
			<div class="row g-4 mb-5">
				<!-- Product Images -->
				<div class="col-md-6">
					<?php woocommerce_show_product_images(); ?>
				</div>
				
				<!-- Product Info -->
				<div class="col-md-6">
					<h1 class="h2 mb-3"><?php the_title(); ?></h1>
					
					<?php if ( $product->get_average_rating() ) : ?>
						<div class="mb-3"><?php woocommerce_template_single_rating(); ?></div>
					<?php endif; ?>
					
					<div class="h3 text-primary mb-3"><?php echo $product->get_price_html(); ?></div>
					
					<?php if ( $product->get_short_description() ) : ?>
						<div class="mb-4"><?php echo $product->get_short_description(); ?></div>
					<?php endif; ?>
					
					<div class="mb-4">
						<?php woocommerce_template_single_add_to_cart(); ?>
					</div>
					
					<div class="border-top pt-3">
						<?php woocommerce_template_single_meta(); ?>
					</div>
				</div>
			</div>
			
			<!-- Product Tabs -->
			<div class="row mb-5">
				<div class="col-12">
					<?php woocommerce_output_product_data_tabs(); ?>
				</div>
			</div>
			
			<!-- Related Products -->
			<?php woocommerce_output_related_products(); ?>
			
		<?php endwhile; ?>
		
	</div>
</div>

<?php get_footer(); ?>

