<?php
/**
 * WooCommerce Shop Page Template - Simplified Bootstrap Version
 * 
 * @package Divi
 * @subpackage WooCommerce
 */

get_header();
?>

<div id="main-content">
	<div class="container py-5">
		
		<?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
			<h1 class="page-title mb-4"><?php woocommerce_page_title(); ?></h1>
		<?php endif; ?>

		<?php
		/**
		 * woocommerce_archive_description hook.
		 */
		do_action( 'woocommerce_archive_description' );
		?>

		<?php if ( woocommerce_product_loop() ) : ?>

			<div class="shop-toolbar d-flex justify-content-between align-items-center mb-4 flex-wrap">
				<?php
				/**
				 * woocommerce_before_shop_loop hook.
				 */
				do_action( 'woocommerce_before_shop_loop' );
				?>
			</div>

			<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
				<?php
				if ( wc_get_loop_prop( 'total' ) ) {
					while ( have_posts() ) {
						the_post();
						
						/**
						 * Hook: woocommerce_shop_loop.
						 */
						do_action( 'woocommerce_shop_loop' );
						
						// Use the reusable product card component
						wc_get_template_part( 'content', 'product' );
					}
				}
				?>
			</div>

			<div class="shop-pagination mt-5">
				<?php
				/**
				 * woocommerce_after_shop_loop hook.
				 */
				do_action( 'woocommerce_after_shop_loop' );
				?>
			</div>

		<?php else : ?>

			<?php
			/**
			 * woocommerce_no_products_found hook.
			 */
			do_action( 'woocommerce_no_products_found' );
			?>

		<?php endif; ?>

	</div>
</div>

<?php get_footer(); ?>
