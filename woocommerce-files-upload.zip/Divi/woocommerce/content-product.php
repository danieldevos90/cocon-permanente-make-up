<?php
/**
 * The template for displaying product content within loops - Reusable Product Card
 *
 * @package Divi
 * @subpackage WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;

// Ensure visibility
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>

<div class="col">
	<div class="product-card card h-100 shadow-sm">
		<a href="<?php echo esc_url( get_permalink() ); ?>" class="product-link">
			<?php if ( has_post_thumbnail() ) : ?>
				<div class="product-image">
					<?php the_post_thumbnail( 'woocommerce_thumbnail', array( 'class' => 'card-img-top' ) ); ?>
				</div>
			<?php else : ?>
				<div class="product-image">
					<img src="<?php echo esc_url( wc_placeholder_img_src() ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" class="card-img-top">
				</div>
			<?php endif; ?>
			
			<?php if ( $product->is_on_sale() ) : ?>
				<span class="badge bg-danger position-absolute top-0 end-0 m-3">Sale</span>
			<?php endif; ?>
		</a>
		
		<div class="card-body d-flex flex-column">
			<div class="product-header d-flex justify-content-between align-items-start mb-2">
				<h5 class="card-title product-title mb-0">
					<a href="<?php echo esc_url( get_permalink() ); ?>">
						<?php the_title(); ?>
					</a>
				</h5>
				
				<div class="product-price">
					<?php echo $product->get_price_html(); ?>
				</div>
			</div>
			
			<?php if ( $product->get_short_description() ) : ?>
				<div class="product-description mb-3">
					<?php echo wp_trim_words( $product->get_short_description(), 15, '...' ); ?>
				</div>
			<?php endif; ?>
			
			<a href="?add-to-cart=<?php echo esc_attr( $product->get_id() ); ?>" 
			   class="btn btn-primary w-100 add-to-cart-btn mt-auto"
			   data-product_id="<?php echo esc_attr( $product->get_id() ); ?>">
				Add to Cart
			</a>
		</div>
	</div>
</div>

