<?php
/**
 * The Template for displaying single product pages - Bootstrap Version
 *
 * @package Divi
 * @subpackage WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_header();

// Get the product object
global $product;

if ( ! $product ) {
	return;
}
?>

<div id="main-content">
	<div class="container py-5">
		
		<?php while ( have_posts() ) : the_post(); ?>
			
			<div class="product-single" itemscope itemtype="http://schema.org/Product">
				
				<!-- Breadcrumb -->
				<nav aria-label="breadcrumb" class="mb-4">
					<?php woocommerce_breadcrumb(); ?>
				</nav>
				
				<div class="row g-5">
					<!-- Product Images -->
					<div class="col-lg-6">
						<div class="product-images sticky-top" style="top: 20px;">
							<?php
							/**
							 * woocommerce_before_single_product_summary hook.
							 *
							 * @hooked woocommerce_show_product_sale_flash - 10
							 * @hooked woocommerce_show_product_images - 20
							 */
							do_action( 'woocommerce_before_single_product_summary' );
							?>
						</div>
					</div>
					
					<!-- Product Info -->
					<div class="col-lg-6">
						<div class="product-info">
							
							<!-- Product Title -->
							<h1 class="product-title mb-3" itemprop="name"><?php the_title(); ?></h1>
							
							<!-- Product Rating -->
							<?php if ( $product->get_average_rating() ) : ?>
								<div class="product-rating mb-3">
									<?php woocommerce_template_single_rating(); ?>
								</div>
							<?php endif; ?>
							
						<!-- Product Price -->
						<div class="product-price-wrapper mb-4">
							<div class="price-large fs-3 fw-bold" itemprop="price" style="color: #ff00ff !important;">
								<?php echo $product->get_price_html(); ?>
							</div>
						</div>
							
							<!-- Product Short Description -->
							<?php if ( $product->get_short_description() ) : ?>
								<div class="product-short-description mb-4" itemprop="description">
									<?php echo $product->get_short_description(); ?>
								</div>
							<?php endif; ?>
							
							<!-- Add to Cart Form -->
							<div class="product-add-to-cart mb-4">
								<?php woocommerce_template_single_add_to_cart(); ?>
							</div>
							
							<!-- Product Meta (SKU, Categories, Tags) -->
							<div class="product-meta border-top pt-4 mt-4">
								<?php woocommerce_template_single_meta(); ?>
							</div>
							
						</div>
					</div>
				</div>
				
				<!-- Product Tabs (Description, Additional Info, Reviews) -->
				<div class="row mt-5">
					<div class="col-12">
						<div class="product-tabs">
							<?php woocommerce_output_product_data_tabs(); ?>
						</div>
					</div>
				</div>
				
				<!-- Related Products -->
				<div class="row mt-5">
					<div class="col-12">
						<?php woocommerce_output_related_products(); ?>
					</div>
				</div>
				
			</div>
			
		<?php endwhile; ?>
		
	</div>
</div>

<?php get_footer(); ?>

