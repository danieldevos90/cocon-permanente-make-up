<?php
/**
 * Related Products - Bootstrap Grid Layout
 *
 * @package Divi
 * @subpackage WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( $related_products ) : ?>

	<section class="related products mt-5">
		<h2 class="h3 mb-4"><?php esc_html_e( 'Related Products', 'woocommerce' ); ?></h2>

		<div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
			<?php foreach ( $related_products as $related_product ) : ?>
				<?php
				$post_object = get_post( $related_product->get_id() );

				setup_postdata( $GLOBALS['post'] =& $post_object );

				// Use the reusable product card component
				wc_get_template_part( 'content', 'product' );
				?>
			<?php endforeach; ?>
		</div>
	</section>

<?php
endif;

wp_reset_postdata();

